const fs = require("fs")

module.exports = async (jrm) => {

  const SlashsArray = []

  fs.readdir(`./Comandos`, (error, folder) => {
    folder.forEach(subfolder => {
      fs.readdir(`./Comandos/${subfolder}/`, (error, files) => {
        files.forEach(files => {

          if (!files?.endsWith('.js')) return;
          files = require(`../Comandos/${subfolder}/${files}`);
          if (!files?.name) return;
          jrm.slashCommands.set(files?.name, files);

          SlashsArray.push(files)
        });
      });
    });
  });
  jrm.on("ready", async () => {
    await jrm.application.commands.set(SlashsArray)
  });
};