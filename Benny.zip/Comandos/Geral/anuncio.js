const { TextInputStyle } = require('discord.js')
const jrmdc = require('discord.js')

module.exports = {
    name: 'anuncio',
    description: '🔔 Enviar um anuncio [ Staff ]',
    type: jrmdc.ApplicationCommandType.ChatInput,
    options: [
        {
            name: "chat",
            description: "📌 Mencione um canal para enviar o anuncio.",
            type: jrmdc.ApplicationCommandOptionType.Channel,
            required: true,
        }
    ],
    run: async (jrm, interaction) => {

        if (!interaction.member.permissions.has(jrmdc.PermissionFlagsBits.ManageMessages))
            return interaction.reply({
                content: `**❌ | ${interaction.user}, Você não possui permissão para utilizar este comando!**`,
                ephemeral: true,
            })

        const modal = new jrmdc.ModalBuilder()
            .setCustomId('MyFirstModal')
            .setTitle('Envie um anuncio 🔪')

        const TítuloEmbed = new jrmdc.TextInputBuilder()
            .setCustomId('TítuloEmbed')
            .setLabel('Título da Embed')
            .setPlaceholder(`Insira o título da Embed.`)
            .setStyle(TextInputStyle.Short)
            .setRequired(true)

        const Descrição = new jrmdc.TextInputBuilder()
            .setCustomId('Descrição')
            .setLabel('Descrição da Embed')
            .setPlaceholder(`Insira a descrição da Embed`)
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true)

        const Thumbnail = new jrmdc.TextInputBuilder()
            .setCustomId('Thumbnail')
            .setLabel('Thumbnail da Embed')
            .setPlaceholder(`Insira a thumbnail da Embed`)
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(false)

        const Image = new jrmdc.TextInputBuilder()
            .setCustomId('Image')
            .setLabel('Imagem da Embed')
            .setPlaceholder(`Insira a imagem da Embed`)
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(false)

        const PrimeiraActionRow = new jrmdc.ActionRowBuilder().addComponents(TítuloEmbed);
        const SegundaActionRow = new jrmdc.ActionRowBuilder().addComponents(Descrição);
        const TerceiraActionRow = new jrmdc.ActionRowBuilder().addComponents(Thumbnail);
        const QuartaActionRow = new jrmdc.ActionRowBuilder().addComponents(Image);

        let chat = interaction.options.getChannel("chat")

        modal.addComponents(PrimeiraActionRow, SegundaActionRow, TerceiraActionRow, QuartaActionRow)

        await interaction.showModal(modal);

        jrm.once('interactionCreate', async interaction => {
            if (!interaction.isModalSubmit()) return;

            if (interaction.customId === 'MyFirstModal') {

                const DescriçãoEmbed = interaction.fields.getTextInputValue('Descrição');
                const TítuloEmbed = interaction.fields.getTextInputValue('TítuloEmbed');
                let ThumbnailEmbed = interaction.fields.getTextInputValue('Thumbnail');
                let ImagemEmbed = interaction.fields.getTextInputValue('Image');

                if (!ThumbnailEmbed) ThumbnailEmbed = ("https://google.com");
                if (!ImagemEmbed) ImagemEmbed = ("https://google.com");

                let embedModal1 = new jrmdc.EmbedBuilder()
                    .setColor(`Red`)
                    .setTitle(`${TítuloEmbed}`)
                    .setDescription(`${DescriçãoEmbed}`)
                    .setThumbnail(`${ThumbnailEmbed}`)
                    .setImage(`${ImagemEmbed}`)

                interaction.reply({
                    content: `**✅ | O anuncio foi enviado com sucesso**`, ephemeral: true
                })


                chat.send({
                    embeds: [embedModal1]
                }).catch((e) => {
                    interaction.reply({ content: `❌ | Algo deu errado, por favor tente novamente...`, ephemeral: true })
                })

            }

        });


    }
}